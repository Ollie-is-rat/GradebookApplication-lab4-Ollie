﻿namespace GradeBook.Enums
{
    public enum EnrollmentType
    {
        Campus,
        State,
        National,
        International
    }
}
